
export interface HurufMateri {
  huruf: string;
  kata: string;
  imageId: string;
}

export interface EjaanMateri {
  id: string;
  kata: string;
  imageId: string;
}

export interface KalimatMateri {
  id: string;
  kalimat: string;
  imageId: string;
  order: number;
}

export const HURUF_ALFABET: HurufMateri[] = [
  { huruf: 'A', kata: 'AYUNAN', imageId: 'ayunan' },
  { huruf: 'B', kata: 'BANGUN', imageId: 'bangun' },
  { huruf: 'C', kata: 'CUCI TANGAN', imageId: 'cuci-tangan' },
  { huruf: 'D', kata: 'DOMBA', imageId: 'ayunan' }, // Defaulting to existing if unique missing
  { huruf: 'E', kata: 'EMBER', imageId: 'mandi' },
  { huruf: 'F', kata: 'FOTO', imageId: 'sekolah' },
  { huruf: 'G', kata: 'GIGI', imageId: 'sikat-gigi' },
  { huruf: 'H', kata: 'HANDUK', imageId: 'mandi' },
  { huruf: 'I', kata: 'IKAN', imageId: 'makan' },
  { huruf: 'J', kata: 'JERAPAH', imageId: 'ayunan' },
  { huruf: 'K', kata: 'KUCING', imageId: 'ayunan' },
  { huruf: 'L', kata: 'LAMPU', imageId: 'tidur' },
  { huruf: 'M', kata: 'MANDI', imageId: 'mandi' },
  { huruf: 'N', kata: 'NASI', imageId: 'makan' },
  { huruf: 'O', kata: 'OBAT', imageId: 'minum' },
  { huruf: 'P', kata: 'PAKAI BAJU', imageId: 'berpakaian' },
  { huruf: 'Q', kata: 'QURAN', imageId: 'sekolah' },
  { huruf: 'R', kata: 'ROTI', imageId: 'makan' },
  { huruf: 'S', kata: 'SEKOLAH', imageId: 'sekolah' },
  { huruf: 'T', kata: 'TIDUR', imageId: 'tidur' },
  { huruf: 'U', kata: 'ULAR', imageId: 'ayunan' },
  { huruf: 'V', kata: 'VAS', imageId: 'ayunan' },
  { huruf: 'W', kata: 'WORTEL', imageId: 'makan' },
  { huruf: 'X', kata: 'XYLOPHONE', imageId: 'ayunan' },
  { huruf: 'Y', kata: 'YOYO', imageId: 'ayunan' },
  { huruf: 'Z', kata: 'ZEBRA', imageId: 'ayunan' },
];

export const EJAAN_MATERI: EjaanMateri[] = [
  { id: 'bangun', kata: 'BANGUN', imageId: 'bangun' },
  { id: 'makan', kata: 'MAKAN', imageId: 'makan' },
  { id: 'mandi', kata: 'MANDI', imageId: 'mandi' },
  { id: 'tidur', kata: 'TIDUR', imageId: 'tidur' },
  { id: 'sekolah', kata: 'SEKOLAH', imageId: 'sekolah' },
];

export const KALIMAT_MATERI: KalimatMateri[] = [
  { id: '1', kalimat: 'SAYA BANGUN PAGI', imageId: 'bangun', order: 1 },
  { id: '2', kalimat: 'SAYA MANDI PAGI', imageId: 'mandi', order: 2 },
  { id: '3', kalimat: 'SAYA MAKAN PAGI', imageId: 'makan', order: 3 },
  { id: '4', kalimat: 'SAYA PERGI KE SEKOLAH', imageId: 'sekolah', order: 4 },
];
