
'use client';

/**
 * AudioCache dihapus karena kita tidak lagi menggunakan audio data URI dari API.
 * Web Speech API berjalan langsung di browser tanpa perlu caching data.
 */
class AudioCache {
  get(text: string): string | null { return null; }
  set(text: string, dataUri: string): void {}
}

export const audioCache = new AudioCache();
