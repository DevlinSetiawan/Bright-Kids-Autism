
export interface Activity {
  id: string;
  title: string;
  image_path: string;
  quiz_prompt: string;
}

export const ACTIVITIES: Activity[] = [
  { id: 'minum', title: 'Minum', image_path: 'minum', quiz_prompt: 'Di mana gambar minum? Silakan pilih!' },
  { id: 'makan', title: 'Makan', image_path: 'makan', quiz_prompt: 'Di mana gambar makan? Silakan pilih!' },
  { id: 'tidur', title: 'Tidur', image_path: 'tidur', quiz_prompt: 'Di mana gambar tidur? Silakan pilih!' },
  { id: 'mandi', title: 'Mandi', image_path: 'mandi', quiz_prompt: 'Di mana gambar mandi? Silakan pilih!' },
  { id: 'sikat-gigi', title: 'Sikat Gigi', image_path: 'sikat-gigi', quiz_prompt: 'Di mana gambar sikat gigi? Silakan pilih!' },
  { id: 'cuci-tangan', title: 'Cuci Tangan', image_path: 'cuci-tangan', quiz_prompt: 'Di mana gambar cuci tangan? Silakan pilih!' },
  { id: 'berpakaian', title: 'Pakai Baju', image_path: 'berpakaian', quiz_prompt: 'Di mana gambar pakai baju? Silakan pilih!' },
  { id: 'pakai-sepatu', title: 'Pakai Sepatu', image_path: 'pakai-sepatu', quiz_prompt: 'Di mana gambar pakai sepatu? Silakan pilih!' },
  { id: 'belajar', title: 'Ambil Buku', image_path: 'belajar', quiz_prompt: 'Di mana gambar buku? Silakan pilih!' },
];

export function getActivityById(id: string) {
  return ACTIVITIES.find(a => a.id === id);
}

export function getNextActivity(id: string) {
  const index = ACTIVITIES.findIndex(a => a.id === id);
  if (index === -1 || index === ACTIVITIES.length - 1) return ACTIVITIES[0];
  return ACTIVITIES[index + 1];
}

export function getPreviousActivity(id: string) {
  const index = ACTIVITIES.findIndex(a => a.id === id);
  if (index === -1 || index === 0) return ACTIVITIES[ACTIVITIES.length - 1];
  return ACTIVITIES[index - 1];
}
