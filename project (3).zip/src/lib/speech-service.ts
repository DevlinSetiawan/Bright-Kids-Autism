
'use client';

/**
 * Layanan suara yang 100% gratis menggunakan Web Speech API.
 * Dioptimalkan untuk mencari suara "Neural" atau "Online" yang kualitasnya 
 * sangat manusiawi (mirip AI) tanpa menggunakan token.
 */
class SpeechService {
  private synth: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.synth = window.speechSynthesis;
    }
  }

  /**
   * Mencari suara terbaik yang tersedia di perangkat.
   * Mengutamakan suara 'Neural' atau 'Natural' dari browser.
   */
  private getBestVoice(): SpeechSynthesisVoice | null {
    if (!this.synth) return null;
    const voices = this.synth.getVoices();
    
    // Cari suara Indonesia (id-ID)
    const idVoices = voices.filter(v => v.lang.includes('id-ID') || v.lang.includes('id_ID'));

    // Prioritas 1: Suara Microsoft Online (Sangat Manusiawi, tersedia di Edge/Chrome)
    const neuralVoice = idVoices.find(v => v.name.toLowerCase().includes('online') || v.name.toLowerCase().includes('natural'));
    if (neuralVoice) return neuralVoice;

    // Prioritas 2: Suara Google (Kualitas sedang)
    const googleVoice = idVoices.find(v => v.name.toLowerCase().includes('google'));
    if (googleVoice) return googleVoice;

    // Prioritas 3: Suara sistem apa saja yang tersedia
    return idVoices[0] || null;
  }

  /**
   * Mengucapkan teks dengan pengaturan yang ceria.
   */
  speak(text: string, onEnd?: () => void) {
    if (!this.synth) return;

    this.cancel();

    // Web Speech API kadang butuh dipicu getVoices() dulu
    if (this.synth.getVoices().length === 0) {
      this.synth.onvoiceschanged = () => this.executeSpeak(text, onEnd);
    } else {
      this.executeSpeak(text, onEnd);
    }
  }

  private executeSpeak(text: string, onEnd?: () => void) {
    if (!this.synth) return;

    const utterance = new SpeechSynthesisUtterance(text);
    const bestVoice = this.getBestVoice();

    if (bestVoice) {
      utterance.voice = bestVoice;
      // Jika menggunakan suara Neural/Online, pitch 1.0 biasanya sudah bagus.
      // Jika suara sistem biasa, kita naikkan pitch-nya.
      const isNeural = bestVoice.name.toLowerCase().includes('online') || bestVoice.name.toLowerCase().includes('natural');
      utterance.pitch = isNeural ? 1.05 : 1.2;
      utterance.rate = isNeural ? 0.95 : 0.9;
    } else {
      utterance.lang = 'id-ID';
      utterance.pitch = 1.2;
      utterance.rate = 0.9;
    }

    utterance.volume = 1.0;

    if (onEnd) {
      utterance.onend = onEnd;
    }

    this.currentUtterance = utterance;
    this.synth.speak(utterance);
  }

  cancel() {
    if (this.synth) {
      this.synth.cancel();
      this.currentUtterance = null;
    }
  }
}

export const speechService = new SpeechService();
