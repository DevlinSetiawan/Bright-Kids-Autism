export const firebaseConfig = {
  "projectId": "studio-872955879-a6c55",
  "appId": "1:691904127984:web:263643dc7c4d00e0b9b335",
  "apiKey": "AIzaSyA3jPXQ8GTRFRJVfzqUGWRgJTigUIw-WxE",
  "authDomain": "studio-872955879-a6c55.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "691904127984"
};
