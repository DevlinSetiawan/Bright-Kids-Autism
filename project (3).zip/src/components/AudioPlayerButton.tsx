"use client";

import { useState } from "react";
import { Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { speechService } from "@/lib/speech-service";

interface AudioPlayerButtonProps {
  title: string;
}

export default function AudioPlayerButton({ title }: AudioPlayerButtonProps) {
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlayAudio = () => {
    setIsPlaying(true);
    speechService.speak(title, () => {
      setIsPlaying(false);
    });
  };

  return (
    <Button
      onClick={handlePlayAudio}
      variant="ghost"
      size="icon"
      className="w-12 h-12 rounded-full hover:bg-slate-100 transition-all active:scale-90"
    >
      <Volume2 className={`w-8 h-8 text-primary ${isPlaying ? 'animate-pulse scale-125' : ''}`} />
    </Button>
  );
}
