import { config } from 'dotenv';
config();

import '@/ai/flows/generate-activity-audio.ts';