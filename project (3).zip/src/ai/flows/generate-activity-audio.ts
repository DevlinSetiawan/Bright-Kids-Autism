
'use server';
/**
 * @fileOverview Genkit flow untuk menghasilkan narasi suara yang sangat manusiawi dan ramah anak.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { googleAI } from '@genkit-ai/google-genai';
import wav from 'wav';
import { Buffer } from 'buffer';

const GenerateActivityAudioInputSchema = z
  .string()
  .describe('Teks yang akan diubah menjadi suara.');
export type GenerateActivityAudioInput = z.infer<typeof GenerateActivityAudioInputSchema>;

const GenerateActivityAudioOutputSchema = z.object({
  audioDataUri: z
    .string()
    .describe('Data audio dalam format base64 WAV data URI.'),
});
export type GenerateActivityAudioOutput = z.infer<typeof GenerateActivityAudioOutputSchema>;

async function toWav(
  pcmData: Buffer,
  channels = 1,
  rate = 24000,
  sampleWidth = 2
): Promise<string> {
  return new Promise((resolve, reject) => {
    const writer = new wav.Writer({
      channels,
      sampleRate: rate,
      bitDepth: sampleWidth * 8,
    });

    let bufs = [] as any[];
    writer.on('error', reject);
    writer.on('data', function (d) {
      bufs.push(d);
    });
    writer.on('end', function () {
      resolve(Buffer.concat(bufs).toString('base64'));
    });

    writer.write(pcmData);
    writer.end();
  });
}

export async function generateActivityAudio(
  input: GenerateActivityAudioInput
): Promise<GenerateActivityAudioOutput> {
  return generateActivityAudioFlow(input);
}

const generateActivityAudioFlow = ai.defineFlow(
  {
    name: 'generateActivityAudioFlow',
    inputSchema: GenerateActivityAudioInputSchema,
    outputSchema: GenerateActivityAudioOutputSchema,
  },
  async (input) => {
    let retries = 2;
    let delay = 1500;

    while (retries >= 0) {
      try {
        const { media } = await ai.generate({
          model: googleAI.model('gemini-2.5-flash-preview-tts'),
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                // 'Algenib' memberikan suara yang sangat natural dan ekspresif
                prebuiltVoiceConfig: { voiceName: 'Algenib' },
              },
            },
          },
          prompt: `Gunakan nada suara yang sangat ramah, ceria, dan jelas seperti berbicara dengan anak kecil. Ucapkan: "${input}"`,
        });

        if (!media) {
          throw new Error('Gagal mendapatkan media audio.');
        }

        const audioBuffer = Buffer.from(
          media.url.substring(media.url.indexOf(',') + 1),
          'base64'
        );

        const wavBase64 = await toWav(audioBuffer);

        return {
          audioDataUri: 'data:audio/wav;base64,' + wavBase64,
        };
      } catch (error: any) {
        if (retries > 0 && (error.message?.includes('429') || error.message?.includes('RESOURCE_EXHAUSTED'))) {
          await new Promise(resolve => setTimeout(resolve, delay));
          retries--;
          delay *= 2;
          continue;
        }
        throw error;
      }
    }
    throw new Error('Kuota suara habis, silakan coba lagi nanti.');
  }
);
