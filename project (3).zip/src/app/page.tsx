
import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-4 md:p-6 relative overflow-hidden">
      <div className="bg-pattern" />
      
      {/* Header with Visual Branding */}
      <div className="flex flex-col items-center mb-6 md:mb-10 mt-4 z-10">
        <h1 className="text-4xl md:text-6xl font-black uppercase tracking-tight text-center leading-none text-kids-outline">
          <div className="flex gap-2 justify-center flex-wrap max-w-xs md:max-w-none">
            <span className="text-[#FF5C5C]">B</span>
            <span className="text-[#FFAE42]">R</span>
            <span className="text-[#FFD700]">I</span>
            <span className="text-[#4CD137]">G</span>
            <span className="text-[#487EB0]">H</span>
            <span className="text-[#4BCFFA]">T</span>
            <span className="mx-1"></span>
            <span className="text-[#A29BFE]">K</span>
            <span className="text-[#FF5C5C]">I</span>
            <span className="text-[#FFAE42]">D</span>
            <span className="text-[#FFD700]">S</span>
          </div>
          <div className="flex gap-2 justify-center mt-2 md:mt-4">
            <span className="text-[#4CD137]">A</span>
            <span className="text-[#487EB0]">U</span>
            <span className="text-[#4BCFFA]">T</span>
            <span className="text-[#A29BFE]">I</span>
            <span className="text-[#FF5C5C]">S</span>
            <span className="text-[#FFAE42]">M</span>
          </div>
        </h1>
      </div>

      {/* Main Buttons - 3 Icons Grid */}
      <div className="w-full max-w-5xl grid grid-cols-1 sm:grid-cols-3 gap-6 md:gap-8 px-4 items-stretch mb-10 z-10">
        {/* Daily Activity */}
        <Link href="/activities" className="group h-full">
          <div className="bg-[#5FB1E8] rounded-[2rem] p-4 md:p-5 border-[6px] border-white shadow-[0_8px_0px_rgba(0,0,0,0.15)] transition-all hover:scale-105 active:scale-95 flex flex-col items-center h-full">
            <div className="bg-white rounded-[1.5rem] p-2 w-full aspect-square max-w-[140px] md:max-w-none relative mb-3 overflow-hidden border-4 border-[#487EB0]/20 flex items-center justify-center">
              <div className="w-full h-full bg-slate-50 rounded-[1rem] border-4 border-dashed border-slate-200 flex items-center justify-center floating">
                <span className="text-slate-300 font-black text-lg md:text-xl uppercase tracking-widest text-center text-kids-pop">DAILY<br/>ACTIVITY</span>
              </div>
            </div>
            <div className="flex-grow flex items-center justify-center">
              <h2 className="text-xl md:text-2xl font-black text-white uppercase text-center leading-tight tracking-tight text-kids-shadow">
                DAILY<br />ACTIVITY
              </h2>
            </div>
          </div>
        </Link>

        {/* Bahasa */}
        <Link href="/bahasa" className="group h-full">
          <div className="bg-[#F5A623] rounded-[2rem] p-4 md:p-5 border-[6px] border-white shadow-[0_8px_0px_rgba(0,0,0,0.15)] transition-all hover:scale-105 active:scale-95 flex flex-col items-center h-full">
            <div className="bg-white rounded-[1.5rem] p-2 w-full aspect-square max-w-[140px] md:max-w-none relative mb-3 overflow-hidden border-4 border-[#FFAE42]/20 flex items-center justify-center">
              <div className="w-full h-full bg-slate-50 rounded-[1rem] border-4 border-dashed border-slate-200 flex items-center justify-center floating">
                <span className="text-slate-300 font-black text-lg md:text-xl uppercase tracking-widest text-center text-kids-pop">BAHASA</span>
              </div>
            </div>
            <div className="flex-grow flex items-center justify-center">
              <h2 className="text-xl md:text-2xl font-black text-white uppercase text-center leading-tight tracking-tight text-kids-shadow">
                BAHASA
              </h2>
            </div>
          </div>
        </Link>

        {/* Quis */}
        <Link href="/quiz" className="group h-full">
          <div className="bg-[#7ED321] rounded-[2rem] p-4 md:p-5 border-[6px] border-white shadow-[0_8px_0px_rgba(0,0,0,0.15)] transition-all hover:scale-105 active:scale-95 flex flex-col items-center h-full">
            <div className="bg-white rounded-[1.5rem] p-2 w-full aspect-square max-w-[140px] md:max-w-none relative mb-3 overflow-hidden border-4 border-[#4CD137]/20 flex items-center justify-center">
              <div className="w-full h-full bg-slate-50 rounded-[1rem] border-4 border-dashed border-slate-200 flex items-center justify-center floating">
                <span className="text-slate-300 font-black text-lg md:text-xl uppercase tracking-widest text-center text-kids-pop">QUIS</span>
              </div>
            </div>
            <div className="flex-grow flex items-center justify-center">
              <h2 className="text-xl md:text-2xl font-black text-white uppercase text-center leading-tight tracking-tight text-kids-shadow">
                QUIS
              </h2>
            </div>
          </div>
        </Link>
      </div>
    </main>
  );
}
