
"use client";

import { useState } from 'react';
import Link from 'next/link';
import { Home, ChevronLeft, Volume2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { HURUF_ALFABET } from '@/lib/bahasa-data';
import { speechService } from '@/lib/speech-service';

export default function HurufPage() {
  const [index, setIndex] = useState(0);
  const item = HURUF_ALFABET[index];

  const handlePlay = () => {
    speechService.speak(`${item.huruf}. ${item.kata}`);
  };

  const next = () => {
    setIndex((prev) => (prev + 1) % HURUF_ALFABET.length);
  };

  const prev = () => {
    setIndex((prev) => (prev - 1 + HURUF_ALFABET.length) % HURUF_ALFABET.length);
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-between p-4 md:p-6 relative overflow-hidden">
      <div className="bg-pattern" />
      
      <header className="w-full flex justify-between items-center z-10">
        <Link href="/bahasa">
          <Button variant="outline" size="icon" className="w-10 h-10 md:w-12 md:h-12 rounded-full border-[4px] border-[#FF5C5C] bg-white shadow-lg">
            <ChevronLeft className="text-[#FF5C5C] w-6 h-6" />
          </Button>
        </Link>
        <h1 className="text-lg md:text-xl font-black text-white text-kids-outline uppercase tracking-tight">ABC CERIA</h1>
        <Link href="/">
          <Button variant="outline" size="icon" className="w-10 h-10 md:w-12 md:h-12 rounded-full border-[4px] border-primary bg-white shadow-lg">
            <Home className="text-primary w-5 h-5" />
          </Button>
        </Link>
      </header>

      <div className="flex flex-col items-center flex-grow justify-center z-10 w-full max-w-sm px-4 my-4">
        <div 
          className="bg-white rounded-[2rem] p-5 md:p-6 border-[6px] border-[#FF5C5C] shadow-xl w-full flex flex-col items-center gap-3 relative transition-all cursor-pointer"
          onClick={handlePlay}
        >
          <div className="bg-[#FF5C5C] text-white w-20 h-20 md:w-24 md:h-24 rounded-full flex items-center justify-center text-4xl md:text-5xl font-black shadow-md border-[4px] border-white mb-1 floating">
            {item.huruf}
          </div>
          
          <div className="w-full aspect-square relative bg-slate-50 rounded-[1.2rem] border-2 border-dashed border-slate-200 overflow-hidden mb-1 shadow-inner flex items-center justify-center">
             <span className="text-slate-300 font-black text-xl md:text-2xl uppercase tracking-widest text-kids-pop">FOTO</span>
          </div>

          <h2 className="text-xl md:text-2xl font-black text-slate-800 uppercase tracking-tight text-center text-kids-shadow">
            {item.kata}
          </h2>
          
          <div className="absolute -bottom-5 bg-[#FF5C5C] h-12 w-12 md:h-14 md:w-14 rounded-full border-[4px] border-white shadow-lg flex items-center justify-center animate-bounce-soft">
            <Volume2 className="w-6 h-6 text-white" />
          </div>
        </div>
      </div>

      <div className="w-full max-w-xs flex justify-between gap-4 z-10 mb-6 px-4">
        <Button 
          onClick={prev} 
          className="flex-1 bg-white text-slate-700 border-[4px] border-[#FF5C5C] h-12 rounded-xl font-black text-base shadow-md active:translate-y-1 transition-all"
        >
          MUNDUR
        </Button>
        <Button 
          onClick={next} 
          className="flex-1 bg-[#FF5C5C] text-white h-12 rounded-xl font-black text-base shadow-md active:translate-y-1 transition-all"
        >
          LANJUT
        </Button>
      </div>
    </main>
  );
}
