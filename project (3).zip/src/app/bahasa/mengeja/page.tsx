
"use client";

import { useState } from 'react';
import Link from 'next/link';
import { Home, ChevronLeft, Play, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { EJAAN_MATERI } from '@/lib/bahasa-data';
import { speechService } from '@/lib/speech-service';

export default function MengejaPage() {
  const [index, setIndex] = useState(0);
  const [activeLetter, setActiveLetter] = useState(-1);
  const [isSpelling, setIsSpelling] = useState(false);
  const item = EJAAN_MATERI[index];

  const handleEja = async () => {
    if (isSpelling) return;
    setIsSpelling(true);
    setActiveLetter(-1);
    const letters = item.kata.split('');
    
    for (let i = 0; i < letters.length; i++) {
      setActiveLetter(i);
      speechService.speak(letters[i]);
      await new Promise(r => setTimeout(r, 900));
    }
    
    setActiveLetter(-1);
    speechService.speak(item.kata);
    setIsSpelling(false);
  };

  const next = () => {
    setIndex((prev) => (prev + 1) % EJAAN_MATERI.length);
    setActiveLetter(-1);
  };

  return (
    <main className="min-h-screen flex flex-col items-center p-4 md:p-6 relative overflow-hidden">
      <div className="bg-pattern" />
      
      <header className="w-full flex justify-between items-center z-10 mb-6">
        <Link href="/bahasa">
          <Button variant="outline" size="icon" className="w-10 h-10 md:w-14 md:h-14 rounded-full border-[4px] border-[#5FB1E8] bg-white shadow-lg">
            <ChevronLeft className="text-[#5FB1E8] w-6 h-6" />
          </Button>
        </Link>
        <h1 className="text-xl md:text-2xl font-black text-white text-kids-outline uppercase">EJA AJAIB</h1>
        <Link href="/">
          <Button variant="outline" size="icon" className="w-10 h-10 md:w-14 md:h-14 rounded-full border-[4px] border-primary bg-white shadow-lg">
            <Home className="text-primary w-5 h-5" />
          </Button>
        </Link>
      </header>

      <div className="bg-white rounded-[2rem] p-6 md:p-8 border-[8px] border-[#5FB1E8] shadow-xl w-full max-w-lg flex flex-col items-center gap-6 z-10 relative">
        <div className="w-full aspect-video bg-slate-50 rounded-[1.5rem] border-[3px] border-dashed border-slate-200 flex items-center justify-center overflow-hidden shadow-inner group relative">
           <div className="text-slate-300 font-black text-2xl md:text-4xl uppercase tracking-[0.1em] group-hover:scale-105 transition-transform">
             FOTO {item.kata}
           </div>
        </div>

        <div className="flex flex-wrap justify-center gap-3 md:gap-4">
          {item.kata.split('').map((char, i) => (
            <div 
              key={i} 
              className={`w-12 h-18 md:w-16 md:h-24 rounded-[1.2rem] flex items-center justify-center text-3xl md:text-5xl font-black border-[6px] transition-all duration-300 shadow-md
                ${activeLetter === i ? 'bg-[#5FB1E8] text-white border-white scale-110 shadow-lg -translate-y-2' : 'bg-slate-50 text-slate-800 border-slate-200'}
              `}
              onClick={() => speechService.speak(char)}
            >
              {char}
            </div>
          ))}
        </div>

        <div className="w-full px-2">
          <Button 
            onClick={handleEja} 
            disabled={isSpelling}
            className="w-full bg-[#5FB1E8] h-14 md:h-18 rounded-full text-lg md:text-xl font-black shadow-[0_6px_0_rgba(0,0,0,0.15)] hover:scale-105 active:scale-95 active:shadow-none transition-all disabled:opacity-50 flex gap-3"
          >
            {isSpelling ? <RefreshCw className="w-6 h-6 animate-spin" /> : <Play className="w-6 h-6 fill-white" />} 
            {isSpelling ? 'MENGEJA...' : 'EJA SEKARANG'}
          </Button>
        </div>
      </div>

      <Button 
        onClick={next} 
        disabled={isSpelling}
        className="mt-8 bg-white text-slate-700 border-[6px] border-[#5FB1E8] h-12 md:h-16 px-8 rounded-full font-black text-lg z-10 shadow-lg hover:bg-slate-50 transition-all hover:scale-105"
      >
        KATA LAINNYA
      </Button>
    </main>
  );
}
