
"use client";

import { useState, useMemo } from 'react';
import Link from 'next/link';
import { Home, ChevronLeft, Volume2, ChevronRight, CheckCircle2, ListOrdered } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { KALIMAT_MATERI, KalimatMateri } from '@/lib/bahasa-data';
import { speechService } from '@/lib/speech-service';

export default function MembacaKalimatPage() {
  const [index, setIndex] = useState(0);
  const [isSequenceMode, setIsSequenceMode] = useState(false);
  const [userSequence, setUserSequence] = useState<KalimatMateri[]>([]);
  const [feedback, setFeedback] = useState<boolean | null>(null);

  const item = KALIMAT_MATERI[index];

  const handlePlay = () => {
    speechService.speak(item.kalimat);
  };

  const next = () => {
    setIndex((prev) => (prev + 1) % KALIMAT_MATERI.length);
  };

  const prev = () => {
    setIndex((prev) => (prev - 1 + KALIMAT_MATERI.length) % KALIMAT_MATERI.length);
  };

  const toggleMode = () => {
    setIsSequenceMode(!isSequenceMode);
    setUserSequence([]);
    setFeedback(null);
    if (!isSequenceMode) {
      speechService.speak("Urutkan aktivitasmu!");
    }
  };

  const handleSequenceClick = (sentence: KalimatMateri) => {
    if (userSequence.includes(sentence)) return;
    
    const nextSequence = [...userSequence, sentence];
    setUserSequence(nextSequence);
    speechService.speak(sentence.kalimat);

    if (nextSequence.length === KALIMAT_MATERI.length) {
      const isCorrect = nextSequence.every((s, i) => s.order === i + 1);
      if (isCorrect) {
        setFeedback(true);
        speechService.speak("Pintar sekali! Urutannya benar!");
        setTimeout(() => {
          setFeedback(null);
          setIsSequenceMode(false);
          setUserSequence([]);
        }, 3000);
      } else {
        setFeedback(false);
        speechService.speak("Coba lagi ya, urutannya belum pas!");
        setTimeout(() => {
          setFeedback(null);
          setUserSequence([]);
        }, 2000);
      }
    }
  };

  const shuffledSentences = useMemo(() => {
    return [...KALIMAT_MATERI].sort(() => Math.random() - 0.5);
  }, [isSequenceMode]);

  return (
    <main className="min-h-screen flex flex-col items-center justify-between p-4 md:p-6 relative overflow-hidden">
      <div className="bg-pattern" />
      
      <header className="w-full flex justify-between items-center z-10">
        <Link href="/bahasa">
          <Button variant="outline" size="icon" className="w-10 h-10 md:w-14 md:h-14 rounded-full border-[4px] border-[#F5A623] bg-white shadow-lg">
            <ChevronLeft className="text-[#F5A623] w-6 h-6" />
          </Button>
        </Link>
        <h1 className="text-xl md:text-2xl font-black text-white text-kids-outline uppercase">KALIMAT PINTAR</h1>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={toggleMode}
            className={`w-10 h-10 md:w-14 md:h-14 rounded-full border-[4px] shadow-lg transition-all ${isSequenceMode ? 'bg-[#F5A623] border-white' : 'bg-white border-[#F5A623]'}`}
          >
            <ListOrdered className={`w-5 h-5 md:w-7 md:h-7 ${isSequenceMode ? 'text-white' : 'text-[#F5A623]'}`} />
          </Button>
          <Link href="/">
            <Button variant="outline" size="icon" className="w-10 h-10 md:w-14 md:h-14 rounded-full border-[4px] border-primary bg-white shadow-lg">
              <Home className="text-primary w-5 h-5" />
            </Button>
          </Link>
        </div>
      </header>

      {!isSequenceMode ? (
        <div className="flex flex-col items-center flex-grow justify-center z-10 w-full max-w-xl px-4 my-4">
          <div 
            className="bg-white rounded-[2.5rem] p-6 md:p-8 border-[8px] border-[#F5A623] shadow-xl w-full flex flex-col items-center gap-6 relative cursor-pointer"
            onClick={handlePlay}
          >
            <div className="w-full max-w-[300px] aspect-video relative bg-slate-50 rounded-[1.5rem] border-[4px] border-dashed border-slate-200 overflow-hidden shadow-inner flex items-center justify-center floating">
              <span className="text-slate-300 font-black text-xl md:text-2xl uppercase tracking-widest text-kids-pop">FOTO</span>
            </div>

            <h2 className="text-2xl md:text-4xl font-black text-slate-800 text-center leading-tight tracking-tight px-2 text-kids-shadow">
              "{item.kalimat}"
            </h2>

            <div className="bg-[#F5A623] h-16 w-16 md:h-20 md:w-20 rounded-full border-[6px] border-white shadow-lg flex items-center justify-center group animate-pulse">
              <Volume2 className="w-8 h-8 md:w-10 md:h-10 text-white transition-transform group-hover:scale-110" />
            </div>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center flex-grow justify-center z-10 w-full max-w-2xl px-4 my-4">
          <div className="bg-white rounded-[2rem] p-6 md:p-8 border-[8px] border-[#F5A623] shadow-xl w-full">
            <h3 className="text-xl md:text-2xl font-black text-slate-800 text-center mb-6 uppercase tracking-tight text-kids-shadow">
              SUSUN URUTAN AKTIVITASMU!
            </h3>
            
            <div className="grid grid-cols-1 gap-3 mb-8">
              {shuffledSentences.map((s) => (
                <Button
                  key={s.id}
                  onClick={() => handleSequenceClick(s)}
                  disabled={userSequence.includes(s)}
                  className={`h-14 md:h-16 rounded-2xl border-4 text-lg md:text-xl font-black shadow-md transition-all
                    ${userSequence.includes(s) ? 'bg-slate-100 border-slate-200 text-slate-300' : 'bg-white border-[#F5A623] text-slate-800 hover:scale-102'}
                  `}
                >
                  {s.kalimat}
                </Button>
              ))}
            </div>

            <div className="flex flex-wrap justify-center gap-2 min-h-[60px] p-4 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
              {userSequence.map((s, i) => (
                <div key={i} className="bg-[#F5A623] text-white px-4 py-2 rounded-full font-black text-sm md:text-base animate-in zoom-in-50">
                  {i + 1}. {s.kalimat}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {!isSequenceMode && (
        <div className="w-full max-w-xs flex justify-around gap-6 z-10 mb-10 px-4">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={prev}
            className="w-14 h-14 md:w-18 md:h-18 rounded-full border-[5px] border-white bg-white shadow-lg hover:scale-110 active:scale-90 transition-all"
          >
            <ChevronLeft className="w-8 h-8 md:w-10 md:h-10 text-slate-600" />
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            onClick={next}
            className="w-14 h-14 md:w-18 md:h-18 rounded-full border-[5px] border-white bg-[#F5A623] shadow-lg hover:scale-110 active:scale-90 transition-all"
          >
            <ChevronRight className="w-8 h-8 md:w-10 md:h-10 text-white" />
          </Button>
        </div>
      )}

      {feedback === true && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black/10 backdrop-blur-sm pointer-events-none">
          <CheckCircle2 className="w-48 h-48 text-[#7ED321] animate-bounce" />
        </div>
      )}
    </main>
  );
}
