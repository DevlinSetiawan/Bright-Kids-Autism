
"use client";

import { useState, useCallback, useEffect } from 'react';
import Link from 'next/link';
import { Home, ChevronLeft, CheckCircle2, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { EJAAN_MATERI, EjaanMateri } from '@/lib/bahasa-data';
import { speechService } from '@/lib/speech-service';

export default function MembacaKataPage() {
  const [index, setIndex] = useState(0);
  const [options, setOptions] = useState<EjaanMateri[]>([]);
  const [feedback, setFeedback] = useState<boolean | null>(null);
  
  const current = EJAAN_MATERI[index];

  const generateOptions = useCallback(() => {
    const others = EJAAN_MATERI.filter(m => m.id !== current.id);
    const shuffled = [...others].sort(() => 0.5 - Math.random());
    const combined = [current, ...shuffled.slice(0, 1)].sort(() => 0.5 - Math.random());
    setOptions(combined);
  }, [current]);

  useEffect(() => {
    generateOptions();
    speechService.speak(`Pilih kata ${current.kata}!`);
  }, [index, generateOptions, current.kata]);

  const handleSelect = (item: EjaanMateri) => {
    if (feedback !== null) return;
    
    if (item.id === current.id) {
      setFeedback(true);
      speechService.speak("Pintar sekali!");
      setTimeout(() => {
        setFeedback(null);
        setIndex((prev) => (prev + 1) % EJAAN_MATERI.length);
      }, 2000);
    } else {
      setFeedback(false);
      speechService.speak("Coba lagi ya!");
      setTimeout(() => setFeedback(null), 1500);
    }
  };

  return (
    <main className="min-h-screen flex flex-col items-center p-4 md:p-6 relative overflow-hidden">
      <div className="bg-pattern" />
      
      <header className="w-full flex justify-between items-center z-10 mb-6">
        <Link href="/bahasa">
          <Button variant="outline" size="icon" className="w-10 h-10 md:w-14 md:h-14 rounded-full border-[4px] border-[#7ED321] bg-white shadow-lg">
            <ChevronLeft className="text-[#7ED321] w-6 h-6" />
          </Button>
        </Link>
        <h1 className="text-xl md:text-2xl font-black text-white text-kids-outline uppercase">KATA PINTAR</h1>
        <Link href="/">
          <Button variant="outline" size="icon" className="w-10 h-10 md:w-14 md:h-14 rounded-full border-[4px] border-primary bg-white shadow-lg">
            <Home className="text-primary w-5 h-5" />
          </Button>
        </Link>
      </header>

      <div className="bg-white rounded-[2rem] p-6 md:p-8 border-[8px] border-[#7ED321] shadow-xl w-full max-w-md flex flex-col items-center gap-6 z-10">
        <div 
          className="w-full aspect-square max-w-[200px] bg-slate-50 rounded-[2rem] border-[4px] border-dashed border-slate-200 flex items-center justify-center overflow-hidden floating shadow-inner cursor-pointer"
          onClick={() => speechService.speak(current.kata)}
        >
           <span className="text-slate-300 font-black text-2xl md:text-3xl uppercase text-center px-6 leading-tight">
             FOTO<br />{current.kata}
           </span>
        </div>

        <p className="text-xl md:text-2xl font-black text-slate-800 text-center text-kids-shadow uppercase tracking-tight">
          PILIH TULISAN YANG PAS!
        </p>

        <div className="grid grid-cols-1 gap-4 w-full px-2">
          {options.map((opt) => (
            <Button 
              key={opt.id}
              onClick={() => handleSelect(opt)}
              className={`h-16 md:h-20 text-2xl md:text-3xl font-black rounded-[1.5rem] border-[6px] shadow-[0_8px_0_rgba(0,0,0,0.1)] transition-all
                ${feedback === true && opt.id === current.id ? 'bg-[#7ED321] border-white text-white scale-105 shadow-none translate-y-1' : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-white'}
                ${feedback === false && opt.id !== current.id ? 'opacity-50' : ''}
              `}
            >
              {opt.kata}
            </Button>
          ))}
        </div>
      </div>
      
      {feedback === true && (
        <div className="fixed inset-0 flex items-center justify-center z-50 pointer-events-none bg-black/5 backdrop-blur-sm">
          <CheckCircle2 className="w-32 h-32 md:w-48 h-48 text-[#7ED321] animate-bounce" />
        </div>
      )}
      {feedback === false && (
        <div className="fixed bottom-10 z-50">
           <div className="bg-[#FF5C5C] text-white px-6 py-3 rounded-full font-black text-xl shadow-xl flex items-center gap-3 animate-shake">
             <XCircle className="w-8 h-8" /> COBA LAGI!
           </div>
        </div>
      )}
    </main>
  );
}
