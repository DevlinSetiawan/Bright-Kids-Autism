
"use client";

import Link from 'next/link';
import { Home, BookOpen, SpellCheck, Type, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { speechService } from '@/lib/speech-service';

const MODULES = [
  { id: 'huruf', title: 'ABC CERIA', icon: Type, color: 'bg-[#FF5C5C]', path: '/bahasa/huruf', desc: 'Kenal Huruf' },
  { id: 'mengeja', title: 'EJA AJAIB', icon: SpellCheck, color: 'bg-[#5FB1E8]', path: '/bahasa/mengeja', desc: 'Belajar Eja' },
  { id: 'kata', title: 'KATA PINTAR', icon: BookOpen, color: 'bg-[#7ED321]', path: '/bahasa/kata', desc: 'Tebak Kata' },
  { id: 'kalimat', title: 'KALIMAT PINTAR', icon: MessageCircle, color: 'bg-[#F5A623]', path: '/bahasa/kalimat', desc: 'Baca Kalimat' },
];

export default function BahasaPage() {
  const handleClick = (title: string) => {
    speechService.speak(title);
  };

  return (
    <main className="min-h-screen p-4 flex flex-col items-center relative overflow-hidden">
      <div className="bg-pattern" />
      
      <header className="w-full max-w-5xl flex items-center justify-between mb-6 mt-4 px-2 z-10">
        <Link href="/">
          <Button 
            variant="outline" 
            size="icon" 
            className="w-10 h-10 md:w-14 md:h-14 rounded-full bg-white border-[4px] border-primary shadow-[0_4px_0px_rgba(0,0,0,0.1)] hover:scale-110 active:scale-95 transition-all"
          >
            <Home className="w-5 h-5 md:w-8 md:h-8 text-primary" />
          </Button>
        </Link>
        <h1 className="text-xl md:text-3xl font-black text-white text-kids-outline uppercase tracking-tight text-center leading-tight cursor-pointer" onClick={() => speechService.speak("Bahasa")}>
          BAHASA
        </h1>
        <div className="w-10 md:w-14" />
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6 w-full max-w-3xl z-10 px-4 mb-10">
        {MODULES.map((mod) => (
          <Link key={mod.id} href={mod.path} onClick={() => handleClick(mod.title)}>
            <div className={`${mod.color} rounded-[1.5rem] md:rounded-[2rem] p-4 md:p-6 border-[6px] border-white shadow-[0_6px_0px_rgba(0,0,0,0.15)] flex items-center gap-4 hover:scale-105 active:scale-95 transition-all group`}>
              <div className="bg-white p-3 rounded-2xl border-4 border-black/5 shadow-inner group-hover:rotate-12 transition-transform shrink-0">
                <mod.icon className="w-8 h-8 md:w-12 md:h-12 text-slate-800" />
              </div>
              <div className="flex flex-col">
                <h2 className="text-lg md:text-2xl font-black text-white text-kids-shadow leading-tight uppercase">
                  {mod.title}
                </h2>
                <span className="text-white/90 font-bold text-xs md:text-sm tracking-widest uppercase">{mod.desc}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </main>
  );
}
