
"use client";

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { ChevronLeft, ChevronRight, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import AudioPlayerButton from '@/components/AudioPlayerButton';
import { getActivityById, getNextActivity, getPreviousActivity } from '@/lib/data';
import { speechService } from '@/lib/speech-service';

export default function ActivityDetailPage() {
  const params = useParams();
  const id = params.id as string;
  
  const activity = getActivityById(id);
  const nextActivity = getNextActivity(id);
  const prevActivity = getPreviousActivity(id);

  if (!activity) {
    return (
      <main className="min-h-screen flex flex-col items-center justify-center p-4">
        <div className="bg-pattern" />
        <h1 className="text-white font-black text-xl mb-4 text-kids-shadow">Aktivitas tidak ditemukan!</h1>
        <Link href="/activities">
          <Button className="bg-white text-primary rounded-full font-black px-6">Kembali</Button>
        </Link>
      </main>
    );
  }

  const handlePlaySound = () => {
    speechService.speak(activity.title);
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-between p-4 md:p-6 relative overflow-hidden">
      <div className="bg-pattern" />

      <div className="w-full flex justify-end z-20">
        <div className="bg-white rounded-full p-2 pr-4 md:p-2 md:pr-6 border-[4px] border-[#5FB1E8] shadow-xl flex items-center gap-2 md:gap-3 transition-transform hover:scale-105">
          <AudioPlayerButton title={activity.title} />
          <div className="text-left" onClick={handlePlaySound}>
            <span className="block font-black text-slate-900 text-sm md:text-lg leading-none uppercase tracking-tight cursor-pointer">{activity.title}</span>
            <span className="text-[8px] md:text-[10px] font-bold text-slate-500 uppercase tracking-widest">Suara</span>
          </div>
        </div>
      </div>

      <div className="relative flex-grow flex items-center justify-center w-full max-w-xl my-4 px-4">
        <div className="absolute inset-0 bg-white/40 rounded-full blur-[40px] md:blur-[60px] scale-110" />
        <div 
          className="relative w-full max-w-[280px] md:max-w-md aspect-square z-10 floating flex items-center justify-center cursor-pointer"
          onClick={handlePlaySound}
        >
          <div className="bg-white rounded-[2rem] md:rounded-[3rem] p-3 md:p-5 w-full h-full border-[6px] md:border-[10px] border-white shadow-2xl flex items-center justify-center overflow-hidden">
             <div className="w-full h-full bg-slate-50 rounded-[1.5rem] md:rounded-[2rem] border-4 border-dashed border-slate-200 flex items-center justify-center">
                <span className="text-slate-300 font-black text-2xl md:text-4xl uppercase tracking-widest text-kids-pop">FOTO</span>
             </div>
          </div>
        </div>
      </div>

      <div className="w-full flex flex-col items-center mb-4 z-10">
        <h1 
          className="text-2xl md:text-4xl font-black text-slate-800 tracking-tighter uppercase text-kids-outline text-center mb-6 md:mb-8 cursor-pointer"
          onClick={handlePlaySound}
        >
          {activity.title}
        </h1>

        <div className="w-full max-w-md flex items-center justify-around gap-4 px-4 pb-4">
          <Link href={`/activities/${prevActivity.id}`}>
            <Button 
              variant="outline" 
              size="icon" 
              className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white border-[4px] md:border-[6px] border-[#5FB1E8] shadow-lg hover:scale-110 active:scale-90 group transition-all"
              onClick={() => speechService.speak("Sebelumnya")}
            >
              <ChevronLeft className="w-6 h-6 md:w-10 md:h-10 text-[#5FB1E8]" />
            </Button>
          </Link>
          
          <Link href="/activities">
            <Button 
              variant="outline" 
              size="icon" 
              className="w-10 h-10 md:w-14 md:h-14 rounded-full bg-white border-[4px] md:border-[6px] border-[#F8B400] shadow-lg hover:scale-110 active:scale-90 transition-all"
            >
              <Home className="w-5 h-5 md:w-8 md:h-8 text-[#F8B400]" />
            </Button>
          </Link>

          <Link href={`/activities/${nextActivity.id}`}>
            <Button 
              variant="outline" 
              size="icon" 
              className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white border-[4px] md:border-[6px] border-[#7ED321] shadow-lg hover:scale-110 active:scale-90 group transition-all"
              onClick={() => speechService.speak("Berikutnya")}
            >
              <ChevronRight className="w-6 h-6 md:w-10 md:h-10 text-[#7ED321]" />
            </Button>
          </Link>
        </div>
      </div>
    </main>
  );
}
