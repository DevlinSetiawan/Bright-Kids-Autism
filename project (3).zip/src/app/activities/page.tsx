
"use client";

import Link from 'next/link';
import { Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ACTIVITIES } from '@/lib/data';
import { speechService } from '@/lib/speech-service';

const COLORS = [
  'bg-[#F8B400]', // Yellow
  'bg-[#5FB1E8]', // Sky Blue
  'bg-[#7ED321]', // Green
  'bg-[#D0021B]', // Red
  'bg-[#F5A623]', // Orange
  'bg-[#BD10E0]', // Purple
  'bg-[#50E3C2]', // Teal
  'bg-[#4A90E2]', // Blue
];

export default function ActivitiesPage() {
  const handleActivityClick = (title: string) => {
    speechService.speak(title);
  };

  return (
    <main className="min-h-screen p-4 flex flex-col items-center relative overflow-x-hidden">
      <div className="bg-pattern" />
      
      <header className="w-full max-w-5xl flex flex-col md:flex-row items-center justify-between mb-8 mt-4 px-2 z-10 gap-4 md:gap-8">
        <Link href="/">
          <Button 
            variant="outline" 
            size="icon" 
            className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white border-[6px] border-primary shadow-lg hover:scale-110 active:scale-95 transition-all"
          >
            <Home className="w-6 h-6 md:w-10 md:h-10 text-primary" />
          </Button>
        </Link>
        
        <h1 className="text-xl md:text-3xl font-black drop-shadow-md uppercase tracking-tighter text-center flex flex-col md:flex-row justify-center items-center gap-y-2 md:gap-x-8">
          <div className="flex gap-1 cursor-pointer" onClick={() => speechService.speak("Daily")}>
            <span className="text-[#FF5C5C] text-kids-outline">D</span>
            <span className="text-[#FFAE42] text-kids-outline">A</span>
            <span className="text-[#FFD700] text-kids-outline">I</span>
            <span className="text-[#4CD137] text-kids-outline">L</span>
            <span className="text-[#487EB0] text-kids-outline">Y</span>
          </div>
          <div className="flex gap-1 cursor-pointer" onClick={() => speechService.speak("Activity")}>
            <span className="text-[#4BCFFA] text-kids-outline">A</span>
            <span className="text-[#A29BFE] text-kids-outline">C</span>
            <span className="text-[#FF5C5C] text-kids-outline">T</span>
            <span className="text-[#FFAE42] text-kids-outline">I</span>
            <span className="text-[#FFD700] text-kids-outline">V</span>
            <span className="text-[#4CD137] text-kids-outline">I</span>
            <span className="text-[#487EB0] text-kids-outline">T</span>
            <span className="text-[#4BCFFA] text-kids-outline">Y</span>
          </div>
        </h1>
        
        <div className="w-12 md:w-16 hidden md:block" />
      </header>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 md:gap-8 w-full max-w-4xl px-4 mb-20 z-10">
        {ACTIVITIES.map((activity, index) => {
          const colorClass = COLORS[index % COLORS.length];
          
          return (
            <Link 
              key={activity.id} 
              href={`/activities/${activity.id}`} 
              className="group"
              onClick={() => handleActivityClick(activity.title)}
            >
              <div className={`${colorClass} rounded-[1.5rem] md:rounded-[2rem] p-3 md:p-4 border-[5px] md:border-[6px] border-white shadow-xl transition-all group-hover:scale-105 active:scale-95 aspect-square relative`}>
                <div className="bg-white rounded-[1rem] md:rounded-[1.2rem] w-full h-full p-1 relative overflow-hidden border-2 border-black/5">
                    <div className="w-full h-full bg-slate-50 rounded-[0.8rem] border-2 border-dashed border-slate-200 flex items-center justify-center">
                      <span className="text-slate-300 font-black text-xs md:text-sm uppercase tracking-widest text-kids-pop">FOTO</span>
                    </div>
                </div>
              </div>
              <p className="mt-2 font-black text-slate-800 text-sm md:text-lg uppercase text-center tracking-tight text-kids-shadow leading-none">
                {activity.title}
              </p>
            </Link>
          );
        })}
      </div>
    </main>
  );
}
