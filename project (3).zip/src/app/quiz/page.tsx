
"use client";

import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { Home, RefreshCw, Volume2, CheckCircle2, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ACTIVITIES, Activity } from '@/lib/data';
import { speechService } from '@/lib/speech-service';

export default function QuizPage() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [options, setOptions] = useState<Activity[]>([]);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const currentActivity = ACTIVITIES[currentQuestionIndex];

  const generateOptions = useCallback(() => {
    const others = ACTIVITIES.filter(a => a.id !== currentActivity.id);
    const shuffledOthers = [...others].sort(() => 0.5 - Math.random());
    const selectedOptions = [currentActivity, ...shuffledOthers.slice(0, 3)];
    setOptions(selectedOptions.sort(() => 0.5 - Math.random()));
  }, [currentActivity]);

  const playPrompt = useCallback(() => {
    if (!currentActivity) return;
    setIsSpeaking(true);
    speechService.speak(currentActivity.quiz_prompt, () => {
      setIsSpeaking(false);
    });
  }, [currentActivity]);

  useEffect(() => {
    if (!quizFinished && currentActivity) {
      const timer = setTimeout(() => {
        playPrompt();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [currentQuestionIndex, quizFinished, currentActivity, playPrompt]);

  useEffect(() => {
    if (!quizFinished) {
      generateOptions();
    }
  }, [currentQuestionIndex, quizFinished, generateOptions]);

  const handleOptionClick = (activity: Activity) => {
    if (feedback !== null) return;

    if (activity.id === currentActivity.id) {
      setFeedback('correct');
      setScore(prev => prev + 1);
      speechService.speak("Pintar sekali!");

      setTimeout(() => {
        setFeedback(null);
        if (currentQuestionIndex < ACTIVITIES.length - 1) {
          setCurrentQuestionIndex(prev => prev + 1);
        } else {
          setQuizFinished(true);
        }
      }, 2000);
    } else {
      setFeedback('wrong');
      speechService.speak("Coba lagi ya!");
      setTimeout(() => setFeedback(null), 1500);
    }
  };

  const restartQuiz = () => {
    setCurrentQuestionIndex(0);
    setScore(0);
    setQuizFinished(false);
    setFeedback(null);
  };

  if (quizFinished) {
    return (
      <main className="min-h-screen flex flex-col items-center justify-center p-6 relative overflow-hidden">
        <div className="bg-pattern" />
        <div className="bg-white rounded-[3rem] p-8 md:p-12 border-[8px] border-primary shadow-2xl flex flex-col items-center z-10 max-w-lg w-full">
          <h1 className="text-4xl md:text-6xl font-black text-primary mb-4 text-center text-kids-outline">HEBAT!</h1>
          <p className="text-xl md:text-2xl font-bold text-slate-600 mb-8 text-center">
            Kamu berhasil menjawab <span className="text-primary text-3xl">{score}</span> pertanyaan!
          </p>
          <div className="flex gap-4">
            <Link href="/">
              <Button variant="outline" className="rounded-full border-4 border-slate-200 h-16 px-8 text-xl font-black">
                <Home className="mr-2 w-6 h-6" /> HOME
              </Button>
            </Link>
            <Button onClick={restartQuiz} className="rounded-full h-16 px-8 text-xl font-black bg-primary">
              <RefreshCw className="mr-2 w-6 h-6" /> LAGI
            </Button>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen flex flex-col items-center p-4 md:p-6 relative overflow-hidden">
      <div className="bg-pattern" />

      <header className="w-full flex justify-between items-center mb-6 z-10">
        <Link href="/">
          <Button variant="outline" size="icon" className="w-12 h-12 rounded-full border-4 border-white bg-white/50">
            <Home className="text-slate-700" />
          </Button>
        </Link>
        <div className="bg-white px-6 py-2 rounded-full border-4 border-primary shadow-md">
          <span className="font-black text-primary text-xl">{currentQuestionIndex + 1} / {ACTIVITIES.length}</span>
        </div>
        <Button 
          onClick={playPrompt} 
          className={`w-12 h-12 rounded-full border-4 border-white p-0 bg-primary ${isSpeaking ? 'animate-bounce' : ''}`}
        >
          <Volume2 />
        </Button>
      </header>

      <div className="text-center mb-8 z-10 px-4">
        <h2 className="text-2xl md:text-4xl font-black text-slate-800 text-kids-outline uppercase tracking-tight">
          DI MANA GAMBAR {currentActivity?.title}?
        </h2>
      </div>

      <div className="grid grid-cols-2 gap-4 md:gap-8 w-full max-w-3xl z-10 mb-8">
        {options.map((option) => {
          return (
            <button
              key={option.id}
              onClick={() => handleOptionClick(option)}
              className={`
                relative bg-white rounded-[2rem] p-3 border-[6px] shadow-lg transition-all active:scale-95 overflow-hidden
                ${feedback === 'correct' && option.id === currentActivity.id ? 'border-[#7ED321] scale-105' : 'border-white'}
                ${feedback === 'wrong' && option.id !== currentActivity.id ? 'opacity-50' : 'opacity-100'}
                hover:border-primary/30
              `}
            >
              <div className="aspect-square bg-slate-50 rounded-[1.5rem] border-2 border-dashed border-slate-200 flex items-center justify-center overflow-hidden">
                 <span className="text-slate-300 font-black text-xl md:text-2xl uppercase tracking-widest text-kids-pop">FOTO</span>
              </div>
              {feedback === 'correct' && option.id === currentActivity.id && (
                <div className="absolute inset-0 flex items-center justify-center bg-[#7ED321]/20 rounded-[1.5rem]">
                  <CheckCircle2 className="w-20 h-20 text-[#7ED321]" />
                </div>
              )}
            </button>
          );
        })}
      </div>

      {feedback === 'wrong' && (
        <div className="fixed bottom-10 animate-bounce-soft z-50">
           <div className="bg-[#D0021B] text-white px-8 py-4 rounded-full font-black text-2xl shadow-2xl flex items-center gap-2">
             <XCircle /> COBA LAGI!
           </div>
        </div>
      )}
      {feedback === 'correct' && (
        <div className="fixed bottom-10 animate-bounce-soft z-50">
           <div className="bg-[#7ED321] text-white px-8 py-4 rounded-full font-black text-2xl shadow-2xl flex items-center gap-2">
             <CheckCircle2 /> PINTAR!
           </div>
        </div>
      )}
    </main>
  );
}
