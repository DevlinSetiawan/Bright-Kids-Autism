# **App Name**: Anak Pintar

## Core Features:

- Daily Activity Data Storage: Store structured data for daily activities, including unique identifiers, titles, image paths, and audio file paths, suitable for cloud-based storage.
- Main Menu Interface: Display a welcoming home screen with clear navigation to key content sections, like 'Daily Activities'.
- Activity Grid Display: Present daily activities in a visually engaging grid layout, showing an image and title for each activity.
- Interactive Activity Detail: Show a full-screen view of an activity with a large character image, prominent text, and a clickable speaker icon to play associated audio.
- Seamless Navigation Controls: Enable intuitive movement between activities using 'Back', 'Home', and 'Next' controls.
- Dynamic Audio Playback: Play pre-recorded or AI-generated audio narrations for each activity upon user interaction (e.g., clicking a speaker icon).
- AI Audio Generation Tool: Utilize a text-to-speech AI tool to dynamically generate child-friendly audio pronunciations or descriptions for activities if pre-recorded audio is unavailable.

## Style Guidelines:

- Background color: Soft sky blue (#87CEEB) to create a calm and inviting atmosphere, as requested by the user.
- Primary interactive color: Warm yellow (#F2C94C) for cards and main interactive elements, providing a cheerful and clear focus, as requested by the user.
- Accent color: Playful orange (#F2994A) for buttons and highlights, offering a vibrant contrast, as requested by the user.
- Body and headline font: 'PT Sans' (humanist sans-serif) for its modern, friendly, and legible appearance suitable for educational content.
- Adopt a consistent flat vector illustration style for all icons and character images, ensuring a clean and child-friendly aesthetic, as suggested by the user for visual assets.
- Utilize large, easily tappable card layouts for menu items and a responsive grid (e.g., 2x4 on larger screens) for activity listings, maintaining proportional spacing for visual balance across various device sizes.
- Implement subtle transition animations when navigating between screens and a gentle scale-up effect upon audio playback to enhance engagement.